package und.urp.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public final class ConfigManager {

    public record Module(int index, String rp, String noRp) {
    }

    private static final String MODULE_PREFIX = "rp-info-";

    private final JavaPlugin plugin;

    private final Map<Integer, Module> modules = new TreeMap<>();

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        modules.clear();

        ConfigurationSection root = plugin.getConfig();
        for (String key : root.getKeys(false)) {
            if (!key.startsWith(MODULE_PREFIX)) {
                continue;
            }

            Integer index = parseIndex(key);
            if (index == null) {
                plugin.getLogger().warning("Пропущен модуль с неверным ключом: " + key);
                continue;
            }

            ConfigurationSection section = root.getConfigurationSection(key);
            if (section == null) {
                plugin.getLogger().warning("Пропущен модуль без секции: " + key);
                continue;
            }

            String rp = section.getString("rp", "");
            String noRp = section.getString("no-rp", "");
            modules.put(index, new Module(index, rp, noRp));
        }
    }

    private Integer parseIndex(String key) {
        String raw = key.substring(MODULE_PREFIX.length());
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public Map<Integer, Module> getModules() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(modules));
    }

    public Module getModule(int index) {
        return modules.get(index);
    }
}
