package und.urp;

import und.urp.config.ConfigManager;
import und.urp.data.PlayerDataManager;
import und.urp.listener.ResourcePackListener;
import und.urp.placeholder.UndRpExpansion;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class UndRp extends JavaPlugin {

    private static final String PAPI = "PlaceholderAPI";

    private ConfigManager configManager;
    private PlayerDataManager dataManager;
    private UndRpExpansion expansion;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.configManager = new ConfigManager(this);
        this.configManager.load();

        this.dataManager = new PlayerDataManager();

        boolean debug = getConfig().getBoolean("debug", false);
        getServer().getPluginManager().registerEvents(new ResourcePackListener(dataManager, debug), this);

        if (configManager.getModules().isEmpty()) {
            getLogger().warning("В config.yml не найдено ни одного модуля rp-info-<N>.");
        } else {
            getLogger().info("Загружено модулей: " + configManager.getModules().size() + ".");
        }

        if (Bukkit.getPluginManager().isPluginEnabled(PAPI)) {
            this.expansion = new UndRpExpansion(this, configManager, dataManager);
            this.expansion.register();
            getLogger().info("Плейсхолдеры зарегистрированы (%undrp_info_<N>%).");
        } else {
            getLogger().warning("PlaceholderAPI не найден — плейсхолдеры не зарегистрированы.");
        }
    }

    @Override
    public void onDisable() {
        if (expansion != null && expansion.isRegistered()) {
            expansion.unregister();
        }
    }
}
