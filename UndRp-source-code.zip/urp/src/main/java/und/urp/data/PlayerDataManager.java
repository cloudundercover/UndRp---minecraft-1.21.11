package und.urp.data;

import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerDataManager {

    private final Map<UUID, PlayerResourcePackStatusEvent.Status> statuses = new ConcurrentHashMap<>();

    public boolean markStatus(Player player, PlayerResourcePackStatusEvent.Status status) {
        PlayerResourcePackStatusEvent.Status previous = statuses.put(player.getUniqueId(), status);
        return previous != status;
    }

    public PlayerResourcePackStatusEvent.Status getStatus(Player player) {
        PlayerResourcePackStatusEvent.Status live = player.getResourcePackStatus();
        if (live != null) {
            return live;
        }
        return statuses.get(player.getUniqueId());
    }

    public boolean isPackApplied(Player player) {
        PlayerResourcePackStatusEvent.Status status = getStatus(player);
        return status == PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED
                || status == PlayerResourcePackStatusEvent.Status.DOWNLOADED;
    }

    public void clear(Player player) {
        statuses.remove(player.getUniqueId());
    }
}
