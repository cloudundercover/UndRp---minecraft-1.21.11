package und.urp.placeholder;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import und.urp.UndRp;
import und.urp.config.ConfigManager;
import und.urp.data.PlayerDataManager;

public final class UndRpExpansion extends PlaceholderExpansion {

    private static final String PARAM_PREFIX = "info_";

    private final UndRp plugin;
    private final ConfigManager config;
    private final PlayerDataManager data;

    public UndRpExpansion(UndRp plugin, ConfigManager config, PlayerDataManager data) {
        this.plugin = plugin;
        this.config = config;
        this.data = data;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "undrp";
    }

    @Override
    public @NotNull String getAuthor() {
        return "undercover";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null || !player.isOnline()) {
            return null;
        }

        Player online = player.getPlayer();
        if (online == null) {
            return null;
        }

        if (!params.startsWith(PARAM_PREFIX)) {
            return null;
        }

        int index;
        try {
            index = Integer.parseInt(params.substring(PARAM_PREFIX.length()));
        } catch (NumberFormatException e) {
            return null;
        }

        ConfigManager.Module module = config.getModule(index);
        if (module == null) {
            return null;
        }

        return data.isPackApplied(online) ? module.rp() : module.noRp();
    }
}
