package und.urp.listener;

import und.urp.data.PlayerDataManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;

public final class ResourcePackListener implements Listener {

    private final PlayerDataManager data;
    private final boolean debug;

    public ResourcePackListener(PlayerDataManager data, boolean debug) {
        this.data = data;
        this.debug = debug;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onResourcePackStatus(PlayerResourcePackStatusEvent event) {
        Player player = event.getPlayer();
        PlayerResourcePackStatusEvent.Status status = event.getStatus();

        boolean changed = data.markStatus(player, status);
        if (debug && changed) {
            Bukkit.getLogger().info("[UndRp] " + player.getName() + " -> " + status);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        data.clear(event.getPlayer());
    }
}
